//
// Created by miguel on 17/02/2021.
//

#ifndef LP2_3_BASE_HPP
#define LP2_3_BASE_HPP

#include <utility>

using std::pair;

class Base {
public:
    virtual double calculateArea();
};


#endif //LP2_3_BASE_HPP
