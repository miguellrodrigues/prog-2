//
// Created by miguel on 17/02/2021.
//

#include "Base.hpp"

double Base::calculateArea() {
    return 0;
}